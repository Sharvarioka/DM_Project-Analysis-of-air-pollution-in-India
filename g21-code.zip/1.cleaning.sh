python3 1.cleaning/DataCleaning.py
