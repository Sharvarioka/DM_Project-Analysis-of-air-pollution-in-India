python3 7.maps/2014mpc-map-generator.py
