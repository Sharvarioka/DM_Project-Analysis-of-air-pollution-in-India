python3 1.cleaning/DataCleaning.py
python3 2.zscore/Air_quality_mpc_zscore.py
python3 3.chi_square/Air_quality_chiscore.py
python3 4.Heatmaps_plots/Heatmaps_barplots.py
python3 5.Clustering/ClusteringStates.py
python3 6.Correlation/Correlation.py
