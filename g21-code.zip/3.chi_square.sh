python3 3.chi_square/Air_quality_chiscore.py
