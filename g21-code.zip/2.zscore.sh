python3 2.zscore/Air_quality_mpc_zscore.py
